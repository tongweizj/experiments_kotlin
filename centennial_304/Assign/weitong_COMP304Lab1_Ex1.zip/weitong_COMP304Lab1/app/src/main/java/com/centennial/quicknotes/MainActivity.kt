package com.centennial.quicknotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue



import com.centennial.quicknotes.ui.home.HomeScreen
import com.centennial.quicknotes.ui.theme.QuickNotesTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            QuickNotesTheme {
//                MyScaffoldWithFAB()
                HomeScreen()
            }
        }
    }
}

//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun MyScaffoldWithFAB() {
//    val navController = rememberNavController()
//    val notes = remember { mutableStateListOf(
//        Note("Meeting Notes", "Discuss project updates and deadlines."),
//        Note("Grocery List", "Buy milk, eggs, and bread."),
//        Note("Workout Plan", "Cardio on Monday, Strength training on Wednesday.")
//    )}
//    Scaffold(
//        // 添加 FloatingActionButton
//        floatingActionButton = {
//            FloatingActionButton(
//                onClick = {  navController.navigate("addNote") },
//                containerColor = MaterialTheme.colorScheme.primary
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Add, // 一个默认的加号图标
//                    contentDescription = "Add"
//                )
//            }
//        }
//    ) { innerPadding ->
//        // Scaffold 的内容区
//        Surface(
//            modifier = Modifier.padding(innerPadding),
//            color = MaterialTheme.colorScheme.background
//        ) {
//            //NotesScreen()
//            NavHost(navController = navController, startDestination = "notes") {
//                composable("notes") { NotesList(navController,notes) }
//                composable("noteDetail/{title}/{content}") { backStackEntry ->
//                    val title = backStackEntry.arguments?.getString("title") ?: "No Title"
//                    val content = backStackEntry.arguments?.getString("content") ?: "No Content"
//                    NoteDetailScreen(title, content, navController)
//                }
//                composable("addNote") { AddNoteScreen(navController, notes) }
//            }
//        }
//    }
//
//}

// 数据模型
//data class Note(val title: String, val content: String)
//
//@Composable
//fun NotesList(navController: NavController,notes: List<Note>) {
//    LazyColumn(modifier = Modifier.padding(16.dp)) {
//        items(notes) { note ->
//            NoteItem(note, navController)
//        }
//    }
//}

//@Composable
//fun NoteItem(note: Note, navController: NavController) {
//    Card(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 8.dp)
//            .clickable {  navController.navigate("noteDetail/${note.title}/${note.content}") }, // 添加点击事件
//        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
//    ) {
//        Column(modifier = Modifier.padding(16.dp)) {
//            Text(text = note.title, style = MaterialTheme.typography.titleMedium)
//            Spacer(modifier = Modifier.height(4.dp))
//            Text(text = note.content, style = MaterialTheme.typography.bodyMedium)
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun NoteDetailScreen(title: String, content: String, navController: NavController) {
//    Scaffold(
//        topBar = {
//            TopAppBar(
//                title = { Text(text = title) },
//                navigationIcon = {
//                    IconButton(onClick = { navController.popBackStack() }) {
//                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
//                    }
//                }
//            )
//        }
//    ) { innerPadding ->
//        Surface(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(innerPadding)
//        ) {
//            Column(modifier = Modifier.padding(16.dp)) {
//                Text(text = content, style = MaterialTheme.typography.bodyLarge)
//            }
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun AddNoteScreen(navController: NavController, notes: MutableList<Note>) {
//    var title by remember { mutableStateOf("") }
//    var content by remember { mutableStateOf("") }
//
//    Scaffold(
//        topBar = {
//            TopAppBar(
//                title = { Text("Add Note") },
//                navigationIcon = {
//                    IconButton(onClick = { navController.popBackStack() }) {
//                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
//                    }
//                }
//            )
//        }
//    ) { innerPadding ->
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(innerPadding)
//                .padding(16.dp)
//        ) {
//            OutlinedTextField(
//                value = title,
//                onValueChange = { title = it },
//                label = { Text("Title") },
//                modifier = Modifier.fillMaxWidth()
//            )
//            Spacer(modifier = Modifier.height(8.dp))
//            OutlinedTextField(
//                value = content,
//                onValueChange = { content = it },
//                label = { Text("Content") },
//                modifier = Modifier.fillMaxWidth()
//            )
//            Spacer(modifier = Modifier.height(16.dp))
//            Row {
//                Button(
//                    onClick = { navController.popBackStack() },
//                    modifier = Modifier.weight(1f)
//                ) {
//                    Text("Cancel")
//                }
//                Spacer(modifier = Modifier.width(8.dp))
//                Button(
//                    onClick = {
//                        if (title.isNotEmpty() && content.isNotEmpty()) {
//                            notes.add(Note(title, content))
//                            navController.popBackStack("notes", false)
//                        }
//                    },
//                    modifier = Modifier.weight(1f)
//                ) {
//                    Text("Save")
//                }
//            }
//        }
//    }
//}

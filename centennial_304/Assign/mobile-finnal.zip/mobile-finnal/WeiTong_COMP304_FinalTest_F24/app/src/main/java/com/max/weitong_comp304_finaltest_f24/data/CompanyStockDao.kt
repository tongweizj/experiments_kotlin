package com.max.weitong_comp304_finaltest_f24.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyStockDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(companyStock: CompanyStock)

    @Update
    suspend fun update(companyStock: CompanyStock)

    @Delete
    suspend fun delete(companyStock: CompanyStock)

    @Query("SELECT * FROM company_stock WHERE companyName = :companyName")
    suspend fun getCompanyStock(companyName: String): CompanyStock?

    @Query("SELECT * FROM company_stock")
    fun getAllCompanyStock(): Flow<List<CompanyStock>>

    @Query("SELECT * FROM company_stock WHERE companyName LIKE :searchQuery")
    fun searchCompanyStocks(searchQuery: String): Flow<List<CompanyStock>>
}


// CompanyStocksViewModel
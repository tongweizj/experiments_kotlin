package com.max.weitong_comp304_finaltest_f24

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn

import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import com.max.weitong_comp304_finaltest_f24.view.MyApp
import com.max.weitong_comp304_finaltest_f24.viewmodel.CompanyStockViewModel
import com.max.weitong_comp304_finaltest_f24.viewmodel.CompanyStockViewModelFactory

import kotlin.getValue
import androidx.compose.material3.*

import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.max.weitong_comp304_finaltest_f24.data.CompanyStock
import com.max.weitong_comp304_finaltest_f24.view.CompanyStockDetailActivity
import com.max.weitong_comp304_finaltest_f24.view.CompanyStockListItem
import kotlinx.coroutines.flow.StateFlow


class MainActivity : ComponentActivity() {
    private val companyStockViewModel: CompanyStockViewModel by viewModels {
        CompanyStockViewModelFactory((application as
                MyApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApp {
                MainActivityContent(companyStockViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainActivityContent(companyStockViewModel: CompanyStockViewModel) {
    val context = LocalContext.current
    var companyName by remember { mutableStateOf("") }
    var openingPrice by remember { mutableStateOf("") }
    var closingPrice by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var searchResult by remember { mutableStateOf<StateFlow<List<CompanyStock>>?>(null) }
    val companyStocs by (searchResult ?: companyStockViewModel.allCompanyStocks).collectAsState()



    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("📝 Stocks Manager") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(text = "Insert Stocks")
            Spacer(modifier = Modifier.height(8.dp))
            TextField(
                value = companyName,
                onValueChange = { companyName = it },
                label = { Text("Company Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextField(
                value = openingPrice,
                onValueChange = { openingPrice =
                    it },
                label = { Text("Opening Price") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            TextField(
                value = closingPrice,
                onValueChange = { closingPrice =
                    it },
                label = { Text("Closing Price") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(onClick = {
                val companyStock = CompanyStock(companyName = companyName, openingPrice = openingPrice.toDouble(), closingPrice = closingPrice.toDouble())
                companyStockViewModel.insert(companyStock)
                companyName = ""
                openingPrice = ""
                closingPrice = ""
            }) {
                Text("Insert Stocks")
            }



            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Display Stock Info")
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(count = companyStocs.size) { index ->
                    val companyStock = companyStocs[index]
                    CompanyStockListItem(
                        companyStock = companyStock,
                        onClick = {
                            val intent = Intent(context,  CompanyStockDetailActivity::class.java)
                            intent.putExtra("companyName", companyStock.companyName)
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}
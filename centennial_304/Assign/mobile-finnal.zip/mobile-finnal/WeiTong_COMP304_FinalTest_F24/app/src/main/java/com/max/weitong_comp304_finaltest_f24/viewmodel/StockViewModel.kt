package com.max.weitong_comp304_finaltest_f24.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.max.weitong_comp304_finaltest_f24.data.CompanyStock
import com.max.weitong_comp304_finaltest_f24.repository.CompanyStockRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CompanyStockViewModel(private val repository: CompanyStockRepository) :
    ViewModel()  {
    val allCompanyStocks: StateFlow<List<CompanyStock>> = repository.allCompanyStocks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun insert(companyStock: CompanyStock) = viewModelScope.launch {
        repository.insert(companyStock)
    }

    fun update(companyStock: CompanyStock) = viewModelScope.launch {
        repository.update(companyStock)
    }

    fun delete(companyStock: CompanyStock) = viewModelScope.launch {
        repository.delete(companyStock)
    }

    suspend fun getCompanyStockOnce(companyName: String): CompanyStock? {
        return repository.getCompanyStock(companyName)
    }
    fun getCompanyStock(companyName: String): StateFlow<CompanyStock?> = flow {
        emit(repository.getCompanyStock(companyName))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    fun searchCompanyStocks(query: String): StateFlow<List<CompanyStock>> =
        repository.searchCompanyStocks(query).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
}

class CompanyStockViewModelFactory(private val repository: CompanyStockRepository) :
    ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return if
                       (modelClass.isAssignableFrom(CompanyStockViewModel::class.java)) {
            CompanyStockViewModel(repository) as T
        } else {
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
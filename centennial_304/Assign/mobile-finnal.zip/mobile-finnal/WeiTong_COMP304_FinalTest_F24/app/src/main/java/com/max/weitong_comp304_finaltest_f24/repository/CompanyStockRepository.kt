package com.max.weitong_comp304_finaltest_f24.repository

import com.max.weitong_comp304_finaltest_f24.data.CompanyStock
import com.max.weitong_comp304_finaltest_f24.data.CompanyStockDao
import kotlinx.coroutines.flow.Flow

class CompanyStockRepository(private val companyStockDao: CompanyStockDao) {
    val allCompanyStocks: Flow<List<CompanyStock>> = companyStockDao.getAllCompanyStock()
    suspend fun insert(companyStock: CompanyStock) {
        companyStockDao.insert(companyStock)
    }
    suspend fun update(companyStock: CompanyStock) {
        companyStockDao.update(companyStock)
    }
    suspend fun delete(companyStock: CompanyStock) {
        companyStockDao.delete(companyStock)
    }
    suspend fun getCompanyStock(companyName: String): CompanyStock? {
        return companyStockDao.getCompanyStock(companyName)
    }
    fun searchCompanyStocks(searchQuery: String): Flow<List<CompanyStock>> {
        return companyStockDao.searchCompanyStocks("%$searchQuery%")
    }
}
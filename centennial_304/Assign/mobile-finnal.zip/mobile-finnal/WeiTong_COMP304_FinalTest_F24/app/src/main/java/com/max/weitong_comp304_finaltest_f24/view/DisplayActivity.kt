package com.max.weitong_comp304_finaltest_f24.view


import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.max.weitong_comp304_finaltest_f24.MyApp
import com.max.weitong_comp304_finaltest_f24.data.CompanyStock
import com.max.weitong_comp304_finaltest_f24.viewmodel.CompanyStockViewModel
import com.max.weitong_comp304_finaltest_f24.viewmodel.CompanyStockViewModelFactory

class CompanyStockDetailActivity : ComponentActivity() {
    private val companyStockViewModel: CompanyStockViewModel by viewModels {
        CompanyStockViewModelFactory((application as
                MyApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApp {
                TaskDetailContent(companyStockViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailContent(companyStockViewModel: CompanyStockViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity
//    val companyName = activity?.intent?.getIntExtra("stockName", "null") ?: "null"
    val companyName = activity
        ?.intent
        ?.getStringExtra("companyName")
        .orEmpty()
    var companyStock by remember { mutableStateOf<CompanyStock?>(null) }
    LaunchedEffect(companyName) {
        companyStock = companyStockViewModel.getCompanyStockOnce(companyName) // 用 suspend 函数单次取值
    }
    companyStock?.let {
        var companyName by remember { mutableStateOf(it.companyName) }
        var openingPrice by remember { mutableStateOf(it.openingPrice) }
        var closingPrice by remember { mutableStateOf(it.closingPrice) }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Stock Detail") },
                    navigationIcon = {
                        IconButton(onClick = { activity?.finish() }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                Text(text = "Stock Details")
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Company Name: " + companyName)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Opening Price: " + openingPrice.toString())
                Text(
                    text = "Closing Price: " + closingPrice.toString())






                Spacer(modifier = Modifier.height(8.dp))


            }
        }
    }
}
@Composable
fun MyApp(content: @Composable () -> Unit) {
    MaterialTheme {
        Surface(color = Color.White) {
            content()
        }
    }
}

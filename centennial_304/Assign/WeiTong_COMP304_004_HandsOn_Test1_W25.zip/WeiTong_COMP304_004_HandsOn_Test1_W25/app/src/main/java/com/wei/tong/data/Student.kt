package com.wei.tong.data

data class Student(
    val name: String,
    val phoneNumber: String,
    val email: String,
    val studentType: String
)
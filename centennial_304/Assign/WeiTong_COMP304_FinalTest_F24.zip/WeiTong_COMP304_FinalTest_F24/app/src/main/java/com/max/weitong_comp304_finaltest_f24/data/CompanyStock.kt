package com.max.weitong_comp304_finaltest_f24.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "company_stock")
data class CompanyStock(
    @PrimaryKey val companyName: String,
    val openingPrice: Double,
    val closingPrice: Double
)

//CompanyStockDetailActivity
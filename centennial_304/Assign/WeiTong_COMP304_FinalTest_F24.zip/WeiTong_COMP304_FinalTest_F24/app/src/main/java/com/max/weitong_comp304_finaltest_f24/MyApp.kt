package com.max.weitong_comp304_finaltest_f24

import android.app.Application
import androidx.room.Room
import com.max.weitong_comp304_finaltest_f24.data.AppDatabase
import com.max.weitong_comp304_finaltest_f24.repository.CompanyStockRepository


class MyApp: Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "companyStockdb"
        ).build()
    }
    val repository: CompanyStockRepository by lazy { // Replace TaskRepository with your actual repository class
        CompanyStockRepository(database.companyStockDao()) // Initialize your repository here
    }
    override fun onCreate() {
        super.onCreate()
    }
}
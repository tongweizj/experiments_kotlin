package com.packt.chapterseven.views

class weatherScreen {
}
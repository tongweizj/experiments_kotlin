package com.packt.chapterseven.data

class WeatherApiResp (
    val current: Weather,
)
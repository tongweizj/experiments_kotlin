package com.example.apparchitectureexample.data

data class Pet(
    val id: Int,
    val name: String,
    val species: String
)
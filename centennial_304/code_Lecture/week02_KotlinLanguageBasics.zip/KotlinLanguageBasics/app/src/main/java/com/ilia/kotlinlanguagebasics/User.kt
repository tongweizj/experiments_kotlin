package com.ilia.kotlinlanguagebasics

data class User(val name: String, val age: Int)

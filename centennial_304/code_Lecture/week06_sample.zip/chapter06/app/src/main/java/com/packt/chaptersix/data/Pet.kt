package com.packt.chaptersix.data

data class Pet(
    val id: Int,
    val name: String,
    val species: String
)